THREE-INSTAGRAM LINK PAGE — SETUP

Files:
- index.html: the black-and-white landing page with all three Instagram profiles.

The profile URLs have been normalized by removing tracking/query parameters:
- https://www.instagram.com/marjoriebrjl/
- https://www.instagram.com/cwenaenj/
- https://www.instagram.com/minasaiko4rigat0/

IMPORTANT:
A QR code that works for other people needs a public URL for this landing page. This folder is not hosted on the internet yet, so a final QR code cannot be made until you publish the page.

Simple free publishing option (GitHub Pages):
1. Sign in to GitHub or create an account.
2. Create a new public repository, for example: instagram-links.
3. Upload index.html to the repository's top level.
4. Open the repository's Settings → Pages.
5. Under Build and deployment, choose Deploy from a branch, select the main branch and /(root), then Save.
6. Wait for GitHub Pages to publish it. The public URL will look like:
   https://YOUR-GITHUB-USERNAME.github.io/instagram-links/
   Use the exact URL shown by GitHub; do not use the example URL above as-is.
7. Send me the published URL. I can then generate a QR code that points to that exact page.

You can preview index.html locally by opening it in a browser, but a locally opened page will not work as a public QR destination for other people.
